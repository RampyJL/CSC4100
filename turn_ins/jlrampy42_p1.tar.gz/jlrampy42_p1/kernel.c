void k_clearscr();
extern void k_print(char *string, int string_length, int row, int col);
void print_border(int start_row, int start_col, int end_row, int end_col);

int main (int argc, char *argv[]) { 
    
    
    k_clearscr();
    print_border(0, 0, 24, 79);
    k_print("Hello World", 11, 11, 34);

    while(1);
    return 0;
 }

// Clear screen function
void k_clearscr() {   
    for(int x = 0; x < 25; x++) {
        for(int y = 0; y < 80; y++) {
            k_print(" ", 1, x, y);
        }
    }
}

// Prints a border along a givin row and column tuple 
void print_border(int start_row, int start_col, int end_row, int end_col) {
    int x = start_row;
    int y = start_col;
    int x_apex = end_row;
    int y_apex = end_col;

    while (x <= x_apex) {
        while (y <= y_apex) {
            if((x == start_row && y == start_col) || (x == start_row && y == y_apex) || (x == x_apex && y == start_col) || (x == x_apex && y == y_apex)) {
                k_print("+", 1, x, y);
            }
            else if (x == start_row || x == x_apex)
            {
                k_print("-", 1, x, y);
            }
            else if (y == start_col || y == y_apex)
            {
                k_print("|", 1, x, y);
            }
            else {
                k_print(" ", 1, x, y);
            }
            y++;
        }
        y = start_col;
        x++;
    }
}